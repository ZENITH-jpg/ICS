/*
 *Name: Tristan Cao
 *Date: 02-12-2024
 *Teacher: Mr. Guglielmi
 *Description: The driver class for the project, main method runs the game from the Concentration
*/
public class Main {
   public static void main(String[] args) {
      Concentration x = new Concentration(); // creates new instance of the Concentration class
      x.game(); // runs the game
   }
}